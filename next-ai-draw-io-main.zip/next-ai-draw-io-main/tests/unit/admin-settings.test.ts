import fs from "fs"
import os from "os"
import path from "path"
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest"
import {
    _resetForTests,
    applyToEnv,
    getEnvFallback,
    getValueSource,
    isSettingsWritable,
    loadSettings,
    saveSettings,
} from "@/lib/admin/settings"

let tmpDir: string

beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "admin-settings-"))
    vi.stubEnv("SETTINGS_FILE", path.join(tmpDir, "settings.json"))
    _resetForTests()
})

afterEach(() => {
    _resetForTests()
    fs.rmSync(tmpDir, { recursive: true, force: true })
    // Written by saveSettings and applyToEnv, not stubbed by every test
    delete process.env.TEST_ADMIN_VAR
})

describe("loadSettings", () => {
    it("returns empty object when file does not exist", () => {
        expect(loadSettings()).toEqual({})
    })

    it("reads values from the settings file", () => {
        fs.writeFileSync(
            process.env.SETTINGS_FILE!,
            JSON.stringify({ version: 1, values: { TEST_ADMIN_VAR: "abc" } }),
        )
        expect(loadSettings()).toEqual({ TEST_ADMIN_VAR: "abc" })
    })

    it("drops non-string values from a corrupted file", () => {
        fs.writeFileSync(
            process.env.SETTINGS_FILE!,
            JSON.stringify({
                version: 1,
                values: {
                    GOOD: "ok",
                    NUM: 5,
                    OBJ: { nested: true },
                    ARR: [1, 2],
                    NULL: null,
                },
            }),
        )
        expect(loadSettings()).toEqual({ GOOD: "ok" })
    })

    it("returns empty object when values is null", () => {
        fs.writeFileSync(
            process.env.SETTINGS_FILE!,
            JSON.stringify({ version: 1, values: null }),
        )
        expect(loadSettings()).toEqual({})
    })

    it("returns empty object when values is an array (no numeric keys)", () => {
        fs.writeFileSync(
            process.env.SETTINGS_FILE!,
            JSON.stringify({ version: 1, values: ["a", "b"] }),
        )
        // Without the Array.isArray guard this would yield { "0": "a", ... }
        expect(loadSettings()).toEqual({})
    })
})

describe("applyToEnv / saveSettings", () => {
    it("overlays file values onto process.env", () => {
        saveSettings({ TEST_ADMIN_VAR: "from-file" })
        expect(process.env.TEST_ADMIN_VAR).toBe("from-file")
    })

    it("file value wins over pre-existing env value", () => {
        vi.stubEnv("TEST_ADMIN_VAR", "from-env")
        saveSettings({ TEST_ADMIN_VAR: "from-file" })
        expect(process.env.TEST_ADMIN_VAR).toBe("from-file")
    })

    it("deleting a key restores the original env value", () => {
        vi.stubEnv("TEST_ADMIN_VAR", "from-env")
        saveSettings({ TEST_ADMIN_VAR: "from-file" })
        saveSettings({ TEST_ADMIN_VAR: null })
        expect(process.env.TEST_ADMIN_VAR).toBe("from-env")
    })

    it("deleting a key unsets env when there was no original value", () => {
        saveSettings({ TEST_ADMIN_VAR: "from-file" })
        saveSettings({ TEST_ADMIN_VAR: null })
        expect(process.env.TEST_ADMIN_VAR).toBeUndefined()
    })

    it("a second module instance can remove a key the first one overlaid", async () => {
        // instrumentation.ts and API routes load separate copies in a build
        vi.stubEnv("TEST_ADMIN_VAR", "from-env")
        fs.writeFileSync(
            process.env.SETTINGS_FILE!,
            JSON.stringify({ version: 1, values: { TEST_ADMIN_VAR: "abc" } }),
        )
        applyToEnv()
        expect(process.env.TEST_ADMIN_VAR).toBe("abc")

        vi.resetModules()
        const second = await import("@/lib/admin/settings")
        expect(second.getValueSource("TEST_ADMIN_VAR")).toBe("file")
        second.saveSettings({ TEST_ADMIN_VAR: null })
        expect(process.env.TEST_ADMIN_VAR).toBe("from-env")
        expect(second.getEnvFallback("TEST_ADMIN_VAR")).toBe("from-env")
    })

    it("persists across cache reset (file round-trip)", () => {
        saveSettings({ TEST_ADMIN_VAR: "persisted" })
        _resetForTests()
        applyToEnv()
        expect(process.env.TEST_ADMIN_VAR).toBe("persisted")
    })
})

describe("getValueSource / getEnvFallback", () => {
    it("reports file source when key is in settings", () => {
        saveSettings({ TEST_ADMIN_VAR: "x" })
        expect(getValueSource("TEST_ADMIN_VAR")).toBe("file")
    })

    it("reports env source when only env is set", () => {
        vi.stubEnv("TEST_ADMIN_VAR", "from-env")
        applyToEnv()
        expect(getValueSource("TEST_ADMIN_VAR")).toBe("env")
    })

    it("reports default when neither is set", () => {
        expect(getValueSource("TEST_ADMIN_VAR")).toBe("default")
    })

    it("returns the shadowed env value as fallback", () => {
        vi.stubEnv("TEST_ADMIN_VAR", "from-env")
        saveSettings({ TEST_ADMIN_VAR: "from-file" })
        expect(getEnvFallback("TEST_ADMIN_VAR")).toBe("from-env")
    })
})

describe("isSettingsWritable", () => {
    it("returns true for a writable temp dir", () => {
        expect(isSettingsWritable()).toBe(true)
    })

    it("returns false when the settings path is a directory", () => {
        _resetForTests()
        vi.stubEnv("SETTINGS_FILE", tmpDir)
        expect(isSettingsWritable()).toBe(false)
    })
})

describe("settings file on disk", () => {
    it("writes valid JSON with restrictive permissions", () => {
        saveSettings({ TEST_ADMIN_VAR: "secret" })
        const filePath = process.env.SETTINGS_FILE!
        const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"))
        expect(parsed).toEqual({
            version: 1,
            values: { TEST_ADMIN_VAR: "secret" },
        })
        if (process.platform !== "win32") {
            const mode = fs.statSync(filePath).mode & 0o777
            expect(mode).toBe(0o600)
        }
    })
})
